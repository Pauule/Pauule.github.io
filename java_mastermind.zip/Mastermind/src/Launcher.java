import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Launcher {

	/*
	 * Launches a new instance of Mastermind and prompts the user to input guesses until he gets the correct solution or reaches a turn-count of 12.
	 */
	public static void main(String[] args) {
		Mastermind game = new Mastermind();
		int turnCounter = 0;
		InputStreamReader sr = null;
		BufferedReader br = null;
		while(!game.isSolved() && turnCounter <= 12) {
			//System.out.println(Arrays.toString(game.getSolution()));
			System.out.println("Type your guess into the console.");
			System.out.println("Your choices of colors are Red, Black, Green, Blue, Yellow and Orange");
			System.out.println("Your guess:");
			sr = new InputStreamReader(System.in);
			br = new BufferedReader(sr);
			try {
				String input = br.readLine();
				if(game.checkInput(input)) {
					int[] result = game.guess(game.parseWordsToInt(input));
					System.out.println("Correct color and position: " + result[0]);
					System.out.println("Correct color: " + result[1]);
					turnCounter++;
				}else {
					System.out.println("The provided input was invalid!");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		try {
			br.close();
			sr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if(game.isSolved()) {
			System.out.println("You solved it!");
			System.out.println("The solution was: " + game.solutionToWords());
			System.out.println("Needed turns: " + turnCounter);
		}else {
			System.out.println("You couldn't get the right solution.");
		}
		
	}

}
