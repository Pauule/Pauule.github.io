import java.util.Random;

public class Mastermind {
	
	private int[] solution;
	private boolean solved;

	/**
	 * Creates a game of Mastermind. Sets a random 4-digit solution.
	 */
	public Mastermind() {
		setSolved(false);
		Random rg = new Random();
		int min = 1, max = 6;
		int[] numbers = {rg.nextInt((max - min) + 1) + min,rg.nextInt((max - min) + 1) + min,rg.nextInt((max - min) + 1) + min,rg.nextInt((max - min) + 1) + min};
		setSolution(numbers);
	}
	
	/**
	 * Runs through all checking methods to rate the users guess.
	 * @param guess int[] containing the numerical values of the users guess
	 * @return An int[] which contains the amount of colors and colors and positions which the user guessed right. (1.colorAndPosition, 2.color)
	 */
	public int[] guess(int[] guess) {
		if(checkWin(guess)) {
			setSolved(true);
			int[] ret = {4, 0};
			return ret;
		}
		int colAndPos = correctColorsAndPositions(guess);
		int colors = correctColors(guess) - colAndPos;
		int[] ret = {colAndPos, colors};
		return ret;
	}
	
	/**
	 * Checks if the provided guess is the same as the solution.
	 * @param guess int[] containing the numerical values of the users guess.
	 * @return Whether or not the user guessed the right combination.
	 */
	private boolean checkWin(int[] guess) {
		boolean fehlerfrei = true;
		for(int i = 0; i < guess.length; i++) {
			if(guess[i] != getSolution()[i]) {
				fehlerfrei = false;
			}
		}
		return fehlerfrei;
	}

	/**
	 * Compares the users guess with the solution.
	 * @param guess int[] containing the numerical values of the users guess.
	 * @return The amount of colors in the correct position which appear in both the solution and the users guess.
	 */
	private int correctColorsAndPositions(int[] guess) {
		int counter = 0;
		for(int i = 0; i < guess.length; i++) {
			if(guess[i] == getSolution()[i]) {
				counter++;
			}
		}
		return counter;
	}

	/**
	 * Compares the users guess with the solution.
	 * @param guess int[] containing the numerical values of the users guess.
	 * @return The amount of colors which appear in both the solution and the users guess.
	 */
	private int correctColors(int[] guess) {
		int counter = 0;
		for(int i : guess) {
			for(int s : getSolution()) {
				if(i == s) {
					i = 0;
					counter++;
				}
			}
		}
		return counter;
	}

	/**
	 * Turns the color names from the checked user input into an int[] which can then be compared to the array provided by getSolution()
	 * @param input A string containing the user input. Has to be checked using checkInput() before.
	 * @return An int Array containing the numerical values of the colors provided by the user.
	 */
	public int[] parseWordsToInt(String input) {
		String[] inputArray = input.split(",");
		int[] guessArray = new int[4];
		for(int i = 0; i < inputArray.length; i++) {
			inputArray[i] = inputArray[i].trim().toLowerCase();
			switch(inputArray[i]) {
			case "red":
				guessArray[i] = 1;
				break;
			case "black":
				guessArray[i] = 2;
				break;
			case "green":
				guessArray[i] = 3;
				break;
			case "blue":
				guessArray[i] = 4;
				break;
			case "yellow":
				guessArray[i] = 5;
				break;
			case "orange":
				guessArray[i] = 6;
				break;
			default:
				break;
			}
		}
		return guessArray;
	}

	/**
	 * Takes a string and checks whether it is in the right format for the game.
	 * @param input A string which should be checked.
	 * @return Whether or not the string contains exactly 4 colors out of the possible.
	 */
	public boolean checkInput(String input) {
		String[] splitInput = input.split(",");
		String[] possibleColors = {"red", "black", "green", "blue", "yellow", "orange"};
		if(splitInput.length < 4) {
			return false;
		}
		for(String s : splitInput) {
			boolean vorhanden = false;
			for(String p : possibleColors) {
				if(s.trim().equalsIgnoreCase(p)) {
					vorhanden = true;
				}
			}
			if(!vorhanden) {
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Turns the int[] getSolution() into a string containing the color names.
	 * @return The numerical solution written out in color names.
	 */
	public String solutionToWords() {
		String answer = "";
		for(int i = 0; i < getSolution().length; i++) {
			switch(getSolution()[i]) {
			case 1:
				answer += "Red, ";
				break;
			case 2:
				answer += "Black, ";
				break;
			case 3:
				answer += "Green, ";
				break;
			case 4:
				answer += "Blue, ";
				break;
			case 5:
				answer += "Yellow, ";
				break;
			case 6:
				answer += "Orange, ";
				break;
			default:
				break;
			}
		}
		answer = answer.substring(0, answer.length()-2);
		return answer;
	}

	/**
	 * @return the solution
	 */
	public int[] getSolution() {
		return solution;
	}

	/**
	 * @param solution the solution to set
	 */
	public void setSolution(int[] solution) {
		this.solution = solution;
	}

	/**
	 * @return the solved
	 */
	public boolean isSolved() {
		return solved;
	}

	/**
	 * @param solved the solved to set
	 */
	public void setSolved(boolean solved) {
		this.solved = solved;
	}
	
}
